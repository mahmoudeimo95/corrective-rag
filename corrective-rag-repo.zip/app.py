import os, re, uuid, torch
import chromadb, docx, gradio as gr
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModelForCausalLM

# ---------- Config ----------
LLM_NAME   = "Qwen/Qwen2.5-3B-Instruct"                         # answer / grader / rewriter
EMBED_NAME = "paraphrase-multilingual-MiniLM-L12-v2"            # Arabic + English
CHUNK_SIZE, CHUNK_OVERLAP = 800, 150
TOP_K = 6
MIN_RELEVANT = 1        # verified chunks needed to answer
MAX_REWRITES = 2        # query rewrites before giving up
NOT_FOUND_MSG = "I couldn't find a reliable answer to this question in the uploaded documents."

# ---------- Models ----------
tok = AutoTokenizer.from_pretrained(LLM_NAME)
llm = AutoModelForCausalLM.from_pretrained(LLM_NAME, torch_dtype=torch.float16, device_map="auto")
embedder = SentenceTransformer(EMBED_NAME)

def chat(system, user, max_new_tokens=400):
    msgs = [{"role": "system", "content": system}, {"role": "user", "content": user}]
    text = tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
    inputs = tok(text, return_tensors="pt").to(llm.device)
    with torch.no_grad():
        out = llm.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
    return tok.decode(out[0][inputs.input_ids.shape[1]:], skip_special_tokens=True).strip()

# ---------- Vector DB ----------
client = chromadb.Client()
col = None
def reset_collection():
    global col
    try: client.delete_collection("docs")
    except Exception: pass
    col = client.create_collection("docs", metadata={"hnsw:space": "cosine"})
reset_collection()


# ---------- Ingestion: extract → clean → split → embed → store ----------
def extract(path):
    name = os.path.basename(path)
    ext = name.lower().rsplit(".", 1)[-1]
    pages = []
    if ext == "pdf":
        for i, p in enumerate(PdfReader(path).pages):
            pages.append((i + 1, p.extract_text() or ""))
    elif ext == "docx":
        d = docx.Document(path)
        pages.append((1, "\n".join(p.text for p in d.paragraphs)))
    else:
        pages.append((1, open(path, encoding="utf-8", errors="ignore").read()))
    return name, pages

def clean(t):
    t = re.sub(r"-\n(\w)", r"\1", t)
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()

def split(text, size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    chunks, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        if end < len(text):
            cut = max(text.rfind("\n", start, end), text.rfind(". ", start, end))
            if cut > start + size * 0.5:
                end = cut + 1
        c = text[start:end].strip()
        if c: chunks.append(c)
        if end >= len(text): break
        start = end - overlap
    return chunks

def ingest(files):
    if not files: return "No files uploaded."
    reset_collection()
    ids, docs, metas = [], [], []
    for f in files:
        path = f if isinstance(f, str) else f.name
        name, pages = extract(path)
        for pg, txt in pages:
            for c in split(clean(txt)):
                ids.append(str(uuid.uuid4())); docs.append(c)
                metas.append({"source": name, "page": pg})
    if not docs: return "No text extracted (scanned PDF? OCR is needed)."
    embs = embedder.encode(docs, batch_size=64, normalize_embeddings=True).tolist()
    col.add(ids=ids, documents=docs, embeddings=embs, metadatas=metas)
    return f"✅ Indexed {len(docs)} chunks from {len(files)} file(s)."


# ---------- Corrective RAG components ----------
def retrieve(q, k=TOP_K):
    e = embedder.encode([q], normalize_embeddings=True).tolist()
    r = col.query(query_embeddings=e, n_results=min(k, col.count()))
    return [{"text": d, "source": m["source"], "page": m["page"], "score": round(1 - dist, 3)}
            for d, m, dist in zip(r["documents"][0], r["metadatas"][0], r["distances"][0])]

GRADE_SYS = "You are a strict relevance grader. Reply with only 'yes' or 'no'."
def grade(question, chunk):
    out = chat(GRADE_SYS,
               f"Question: {question}\n\nPassage:\n{chunk}\n\n"
               "Does this passage contain information that helps answer the question?",
               max_new_tokens=3)
    return out.lower().startswith("yes")

def rewrite(question, tried):
    out = chat("You rewrite questions into better search queries for a document search engine. "
               "Use different keywords or synonyms, keep the same language as the question. "
               "Output only the new query.",
               f"Original question: {question}\nQueries already tried (do not repeat): {tried}\nNew query:",
               max_new_tokens=60)
    return out.split("\n")[0].strip().strip('"')

GEN_SYS = ("Answer the question using ONLY the numbered context passages. "
           "Cite passages like [1], [2]. Reply in the same language as the question. "
           "If the context does not contain the answer, reply exactly: NOT_FOUND")

def corrective_rag(question):
    trace, tried, q, verified = [], [question], question, []
    for attempt in range(MAX_REWRITES + 1):
        hits = retrieve(q)
        graded = [(h, grade(question, h["text"])) for h in hits]
        good = [h for h, ok in graded if ok]
        trace.append(f"**Attempt {attempt + 1}** — query: `{q}` → retrieved {len(hits)}, "
                     f"relevant {len(good)}")
        if len(good) >= MIN_RELEVANT:
            verified = good
            break
        if attempt < MAX_REWRITES:
            q = rewrite(question, tried)
            tried.append(q)
            trace.append(f"⚠️ Weak context → rewrote query to: `{q}`")

    if not verified:
        trace.append("❌ No verified context found.")
        return NOT_FOUND_MSG, "", "\n\n".join(trace)

    context = "\n\n".join(f"[{i+1}] {h['text']}" for i, h in enumerate(verified))
    answer = chat(GEN_SYS, f"Context:\n{context}\n\nQuestion: {question}")
    if "NOT_FOUND" in answer:
        trace.append("❌ Generator found no answer in verified context.")
        return NOT_FOUND_MSG, "", "\n\n".join(trace)

    sources = "\n\n".join(
        f"**[{i+1}] {h['source']} — page {h['page']}** (similarity {h['score']})\n> {h['text'][:300]}…"
        for i, h in enumerate(verified))
    trace.append("✅ Answer generated from verified context.")
    return answer, sources, "\n\n".join(trace)


# ---------- Gradio app ----------
def ask(question):
    if not question.strip(): return "Please enter a question.", "", ""
    if col.count() == 0: return "Please upload and index documents first.", "", ""
    return corrective_rag(question)

with gr.Blocks(title="Corrective RAG") as demo:
    gr.Markdown("# 📚 Corrective RAG\nUpload documents, then ask questions. Answers come only from verified context.")
    with gr.Row():
        files = gr.File(label="Documents (PDF, DOCX, TXT)", file_count="multiple",
                        file_types=[".pdf", ".docx", ".txt"], type="filepath")
        with gr.Column():
            status = gr.Textbox(label="Status", interactive=False)
            gr.Button("Index documents", variant="primary").click(ingest, files, status)
    q = gr.Textbox(label="Your question", placeholder="Ask something about your documents…")
    btn = gr.Button("Ask", variant="primary")
    gr.Markdown("### Answer")
    ans = gr.Markdown()
    gr.Markdown("### Sources")
    src = gr.Markdown()
    gr.Markdown("### Pipeline trace")
    trc = gr.Markdown()
    btn.click(ask, q, [ans, src, trc])
    q.submit(ask, q, [ans, src, trc])

if __name__ == "__main__":
    demo.launch(share=True)
